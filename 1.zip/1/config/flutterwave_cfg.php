<?php

  // API credentials

  define('FLUTTERWAVE_SECRETKEY', 'key');	// test key: FLWSECK_TEST-00846e19917eef0712e25f688857b80e-X

  // other
  
  define('FLUTTERWAVE_PM_OPTS', 'card');

  // API URL

  define('FLUTTERWAVE_API_URL', 'https://api.flutterwave.com/v3/payments');
  define('FLUTTERWAVE_RETURN_URL', 'flutterwave_return.php');
?>
