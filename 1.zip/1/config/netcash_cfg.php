<?php

  // Netcash credentials
  
  define('NETCASH_SRVKEY', 'service_key');	// test service key: 33ed960f-4ac4-4c2a-ad61-eee9f1243194
  define('NETCASH_EMAIL',  'email_address');

?>
